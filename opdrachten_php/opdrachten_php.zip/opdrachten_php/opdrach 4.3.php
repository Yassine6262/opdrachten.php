<?php
$var1 = 30;
$var2 = 40;

if($var1 > $var2){
 echo $som = $var1 * 2 + $var2;
}
else{
    echo $som = $var2 / 2 + $var1;
}
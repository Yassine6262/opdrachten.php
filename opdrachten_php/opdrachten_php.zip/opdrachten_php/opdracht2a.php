<?php
$txt = "HALLO ALLEMAAL";


echo $txt;
echo "<br>";

echo "<br>";

?>

<?php
echo "<h2>PHP</h2>";
echo "Hallo ik ben Yassine<br>";
echo "Dit is mijn php<br>";

$schoolnaam = "Techniek College Rotterdam !";

echo "$schoolnaam";
?>
<?php
$txt = "HALLO ALLEMAAL";
$x = 5;
$y = 10.5;

echo $txt;
echo "<br>";
echo $x;
echo "<br>";
echo $y;
?>

<?php
echo "<h2>PHP</h2>";
echo "Hallo ik ben Yassine<br>";
echo "Dit is mijn php<br>";

$schoolnaam = "Techniek College Rotterdam !";

echo "$schoolnaam";
?>